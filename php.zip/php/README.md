# Installation
composer require linecorp/line-bot-sdk